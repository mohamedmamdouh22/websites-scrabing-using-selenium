<?php
if ( ! defined( 'ABSPATH' ) ) exit;

?>
<svg height="512" viewBox="0 0 128 128" width="0" xmlns="http://www.w3.org/2000/svg"><g id="file_upload" data-name="Circle Grid"><circle cx="64" cy="64" class="quarterly" r="64"/></g><g id="icon"><path d="m19.335 67.454a13.327 13.327 0 0 0 13.47 13.3h62.73a13.274 13.274 0 0 0 13.13-13.3 13.138 13.138 0 0 0 -11.6-13.05 11.074 11.074 0 0 0 1.42-5.46 11.259 11.259 0 0 0 -19.35-7.84 15.5 15.5 0 0 0 -30.09 1.06 10.7 10.7 0 0 0 -15.9 11.83c-.11-.01-.23-.01-.34-.01a13.469 13.469 0 0 0 -13.47 13.47z" class="primary"/><path d="m49.705 73.291 14.291-18 14.299 18h-7.257v24.875h-13.833v-24.875z" class="secondary"/></g></svg>